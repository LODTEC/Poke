package com.lodtec.shinybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class BotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BotService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var hudBox: LinearLayout? = null
    private var ctrlBox: LinearLayout? = null
    private var calView: FrameLayout? = null
    private lateinit var tvState: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvCaps: TextView
    private lateinit var tvFound: TextView
    private lateinit var btnToggle: TextView

    @Volatile private var running = false
    private var worker: Thread? = null
    private var startMs = 0L
    @Volatile private var elapsedBefore = 0L
    @Volatile private var captures = 0
    @Volatile private var found = 0
    @Volatile private var lastShotMs = 0L

    private val NEON = Color.parseColor("#3DDC84")
    private val RED = Color.parseColor("#FF5C5C")
    private val MUTED = Color.parseColor("#8D96D6")
    private val WHITE = Color.parseColor("#F2F4FF")
    private val DARK = Color.parseColor("#0B0D1F")
    private val PURPLE = Color.parseColor("#7B5CD6")
    private val ORANGE = Color.parseColor("#FF8F5C")

    private val ticker = object : Runnable {
        override fun run() {
            tvTime.text = fmtTime(elapsedSec())
            if (running) main.postDelayed(this, 1000)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildHud()
        buildControls()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        running = false
    }

    override fun onDestroy() {
        running = false
        instance = null
        try { hudBox?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { ctrlBox?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { calView?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screen(): Rect = wm.currentWindowMetrics.bounds

    private fun rounded(color: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(12).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun statCell(label: String): Pair<LinearLayout, TextView> {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val l = TextView(this).apply {
            text = label
            textSize = 9f
            setTextColor(MUTED)
        }
        val v = TextView(this).apply {
            text = "0"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(WHITE)
        }
        cell.addView(l)
        cell.addView(v)
        return Pair(cell, v)
    }

    private fun buildHud() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(Color.parseColor("#D905071A"), NEON)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply {
            text = "SHINY BOT"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(NEON)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvState = TextView(this).apply {
            text = "OFF"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(RED)
        }
        head.addView(title)
        head.addView(tvState)

        tvStatus = TextView(this).apply {
            text = "Pronto para iniciar"
            textSize = 12f
            maxLines = 3
            setTextColor(WHITE)
            setPadding(0, dp(2), 0, dp(4))
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val (c1, v1) = statCell("TEMPO")
        val (c2, v2) = statCell("CAPTURAS")
        val (c3, v3) = statCell("ACHADOS")
        tvTime = v1
        tvTime.text = "00:00:00"
        tvCaps = v2
        tvFound = v3
        row.addView(c1)
        row.addView(c2)
        row.addView(c3)

        box.addView(head)
        box.addView(tvStatus)
        box.addView(row)

        val lp = WindowManager.LayoutParams(
            (screen().width() * 0.52f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(40)
        }
        wm.addView(box, lp)
        hudBox = box
    }

    private fun pill(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(DARK)
        background = rounded(NEON)
        layoutParams = LinearLayout.LayoutParams(dp(72), dp(44)).apply { bottomMargin = dp(6) }
    }

    private fun smallBtn(text: String, bg: Int, fg: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = rounded(bg)
        setPadding(dp(8), dp(10), dp(8), dp(10))
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { marginEnd = dp(6) }
    }

    private fun buildControls() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btnToggle = pill("ON")
        val btnTest = pill("TESTE")
        btnTest.background = rounded(PURPLE)
        btnTest.setTextColor(WHITE)
        val btnCal = pill("CALIBRAR")
        btnCal.background = rounded(ORANGE)
        box.addView(btnToggle)
        box.addView(btnTest)
        box.addView(btnCal)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screen().width() - dp(84)
            y = (screen().height() * 0.62f).toInt()
        }

        attachDrag(btnToggle, lp, box, { toggleBot() }, { resetStats() })
        attachDrag(btnTest, lp, box, { diagnose() }, null)
        attachDrag(btnCal, lp, box, { startCalibration() }, null)

        wm.addView(box, lp)
        ctrlBox = box
    }

    private fun attachDrag(
        v: View,
        lp: WindowManager.LayoutParams,
        container: View,
        onClick: () -> Unit,
        onLong: (() -> Unit)?
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var downT = 0L
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    downT = SystemClock.elapsedRealtime()
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (abs(mx) > dp(8) || abs(my) > dp(8)) moved = true
                    if (moved) {
                        lp.x = startX + mx
                        lp.y = startY + my
                        wm.updateViewLayout(container, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val long = SystemClock.elapsedRealtime() - downT > 700
                        if (long && onLong != null) onLong() else onClick()
                    }
                }
            }
            true
        }
    }

    private fun updateToggle() {
        if (running) {
            btnToggle.text = "OFF"
            btnToggle.background = rounded(RED)
            tvState.text = "ON"
            tvState.setTextColor(NEON)
        } else {
            btnToggle.text = "ON"
            btnToggle.background = rounded(NEON)
            tvState.text = "OFF"
            tvState.setTextColor(RED)
        }
    }

    private fun say(msg: String) {
        main.post { tvStatus.text = msg }
    }

    private fun updateStats() {
        main.post {
            tvCaps.text = captures.toString()
            tvFound.text = found.toString()
        }
    }

    private fun fmtTime(s: Long): String =
        String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)

    private fun elapsedSec(): Long =
        if (running) (SystemClock.elapsedRealtime() - startMs) / 1000 else elapsedBefore / 1000

    // ---------------------------------------------------------------- calibracao por toque

    private fun startCalibration() {
        if (running) {
            say("Pare o bot antes de calibrar")
            return
        }
        if (calView != null) return
        val sr = screen()
        val steps = listOf(
            Triple("Toque no 1º Pokémon da coluna ESQUERDA", "leftX", "leftY"),
            Triple("Toque no 1º slot da coluna DIREITA", "rightX", "rightY")
        )
        var idx = 0

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#55000000")) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.parseColor("#EE05071A"), NEON)
            isClickable = true
        }
        val tvStep = TextView(this).apply {
            textSize = 11f
            setTextColor(MUTED)
        }
        val tvIns = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(WHITE)
            setPadding(0, dp(2), 0, dp(8))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bSkip = smallBtn("PULAR", PURPLE, WHITE)
        val bCancel = smallBtn("CANCELAR", RED, DARK)
        row.addView(bSkip)
        row.addView(bCancel)
        card.addView(tvStep)
        card.addView(tvIns)
        card.addView(row)
        frame.addView(
            card,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply { setMargins(dp(12), 0, dp(12), dp(48)) }
        )

        fun refresh() {
            tvStep.text = "CALIBRAÇÃO ${idx + 1}/${steps.size}"
            tvIns.text = steps[idx].first
        }

        fun close(msg: String) {
            try { wm.removeView(frame) } catch (_: Exception) {}
            calView = null
            say(msg)
        }

        fun next() {
            idx++
            if (idx >= steps.size) close("Calibração salva") else refresh()
        }

        bSkip.setOnClickListener { next() }
        bCancel.setOnClickListener { close("Calibração cancelada") }

        frame.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                val fx = (e.rawX / sr.width()).coerceIn(0f, 1f)
                val fy = (e.rawY / sr.height()).coerceIn(0f, 1f)
                Config.set(applicationContext, steps[idx].second, fx)
                Config.set(applicationContext, steps[idx].third, fy)
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setStroke(dp(2), NEON)
                        setColor(0x553DDC84)
                    }
                }
                val dlp = FrameLayout.LayoutParams(dp(24), dp(24))
                dlp.leftMargin = (e.rawX - dp(12)).toInt()
                dlp.topMargin = (e.rawY - dp(12)).toInt()
                frame.addView(dot, dlp)
                next()
            }
            true
        }

        refresh()
        val lp = WindowManager.LayoutParams(
            sr.width(),
            sr.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(frame, lp)
        calView = frame
    }

    // ---------------------------------------------------------------- controle

    private fun toggleBot() {
        if (running) stopBot() else startBot()
    }

    private fun startBot() {
        if (running) return
        if (calView != null) {
            say("Termine a calibração primeiro")
            return
        }
        if (worker?.isAlive == true) {
            say("Aguarde o bot terminar de parar...")
            return
        }
        running = true
        startMs = SystemClock.elapsedRealtime() - elapsedBefore
        updateToggle()
        main.removeCallbacks(ticker)
        main.post(ticker)
        worker = Thread { loop() }.apply {
            isDaemon = true
            start()
        }
    }

    private fun stopBot() {
        if (!running) return
        running = false
        say("Parando...")
    }

    private fun resetStats() {
        if (running) {
            say("Pare o bot antes de zerar os contadores")
            return
        }
        captures = 0
        found = 0
        elapsedBefore = 0
        updateStats()
        main.post {
            tvTime.text = "00:00:00"
            tvStatus.text = "Contadores zerados"
        }
    }

    private fun diagnose() {
        if (running) {
            say("Pare o bot para usar o teste")
            return
        }
        Thread {
            say("Testando... não mexa na tela por 3s")
            val a = shot()
            val b = shot()
            if (a == null || b == null) {
                say("Teste: falha ao capturar a tela")
                return@Thread
            }
            val ctx = applicationContext
            val ch = Detector.slotChange(a, b, ctx)
            val tm = Detector.timerState(b, ctx)
            val pt = Detector.popupButton(b, ctx)
            a.recycle()
            b.recycle()
            val av = if (pt != null) "SIM" else "não"
            say("Teste: mudança na direita $ch% (vazia = perto de 0) | timer $tm | aviso $av")
        }.start()
    }

    // ---------------------------------------------------------------- loop principal

    private fun confirmPopup(pt: FloatArray) {
        say("Aviso detectado (velocidade ou clima). Confirmando...")
        tapRel(pt[0], pt[1])
        sleepMs(1500)
    }

    /** Print que ja confirma avisos (velocidade, clima...) se algum estiver na tela. */
    private fun look(): Bitmap? {
        for (i in 0 until 3) {
            val b = shot() ?: return null
            val pt = Detector.popupButton(b, applicationContext)
            if (pt == null) return b
            b.recycle()
            confirmPopup(pt)
        }
        return shot()
    }

    private fun loop() {
        val c = applicationContext
        var finalMsg = "Bot parado"
        try {
            while (running) {
                say("Preparando a busca...")
                val base = look()
                if (base == null) {
                    say("Falha ao capturar a tela. Tentando de novo...")
                    sleepMs(1500)
                    continue
                }

                say("Procurando pokémon shiny...")
                tapRel(Config.get(c, "leftX"), Config.get(c, "leftY"))
                if (!countdown("Aguardando o radar", Config.get(c, "waitSec").toInt().coerceAtLeast(1), true)) {
                    base.recycle()
                    break
                }

                say("Verificando coluna da direita...")
                val now = look()
                if (now == null) {
                    base.recycle()
                    say("Falha ao capturar a tela. Tentando de novo...")
                    sleepMs(1500)
                    continue
                }
                val change = Detector.slotChange(base, now, c)
                base.recycle()
                if (change < Config.get(c, "minPct").toInt()) {
                    now.recycle()
                    say("Nada na direita (mudança $change%). Repetindo a busca...")
                    sleepMs(800)
                    continue
                }

                say("Algo apareceu na direita! Abrindo a captura...")
                doubleTapRel(Config.get(c, "rightX"), Config.get(c, "rightY"))
                sleepMs(Config.get(c, "openWaitMs").toLong())
                if (!running) {
                    now.recycle()
                    break
                }

                say("Confirmando a tela de captura...")
                val cap = look()
                if (cap == null) {
                    now.recycle()
                    say("Falha ao capturar a tela. Tentando de novo...")
                    sleepMs(1500)
                    continue
                }
                val sd = Detector.sceneDiff(now, cap)
                now.recycle()
                if (sd < Config.get(c, "capDiff").toInt()) {
                    cap.recycle()
                    say("A captura não abriu (diferença $sd). Voltando a procurar...")
                    sleepMs(1500)
                    continue
                }

                found++
                updateStats()
                say("Tirando print da captura...")
                if (Config.get(c, "savePrints") > 0f) save(cap)

                var cur: Bitmap? = cap
                var tooLong = false
                val t0 = SystemClock.elapsedRealtime()
                val maxMs = (Config.get(c, "cdMaxSec") * 1000f).toLong()
                while (running) {
                    val st = if (cur != null) Detector.timerState(cur, c) else TimerState.UNKNOWN
                    cur?.recycle()
                    cur = null
                    if (st != TimerState.RED) break
                    if (SystemClock.elapsedRealtime() - t0 > maxMs) {
                        tooLong = true
                        break
                    }
                    say("Timer vermelho. Esperando ficar verde...")
                    sleepMs(1200)
                    cur = shot()
                }
                if (!running) break
                if (tooLong) {
                    finalMsg = "O timer demorou demais para ficar verde. Bot parado."
                    break
                }

                say("Jogando a pokébola!")
                throwBall()
                captures++
                updateStats()
                if (!countdown("Captura contada. Aguardando o resultado", Config.get(c, "postWaitSec").toInt().coerceAtLeast(1), false)) break

                if (Config.get(c, "useBack") > 0f) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    sleepMs(1000)
                }
            }
        } finally {
            running = false
            elapsedBefore = SystemClock.elapsedRealtime() - startMs
            main.post {
                updateToggle()
                tvStatus.text = finalMsg
                tvTime.text = fmtTime(elapsedBefore / 1000)
            }
        }
    }

    private fun sleepMs(ms: Long) {
        var left = ms
        while (left > 0 && running) {
            val d = minOf(left, 200L)
            Thread.sleep(d)
            left -= d
        }
    }

    private fun countdown(label: String, secs: Int, watch: Boolean): Boolean {
        var s = secs
        var n = 0
        while (s > 0 && running) {
            say("$label... ${s}s")
            sleepMs(1000)
            s--
            n++
            if (watch && s > 3 && n % 10 == 0 && running) {
                val b = shot()
                if (b != null) {
                    val pt = Detector.popupButton(b, applicationContext)
                    b.recycle()
                    if (pt != null) confirmPopup(pt)
                }
            }
        }
        return running
    }

    // ---------------------------------------------------------------- toques e print

    private fun gesture(path: Path, dur: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val posted = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, main)
        if (!posted) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        gesture(p, 60)
    }

    private fun tapRel(fx: Float, fy: Float) {
        val r = screen()
        tap(fx * r.width(), fy * r.height())
    }

    private fun doubleTapRel(fx: Float, fy: Float) {
        tapRel(fx, fy)
        sleepMs(130)
        tapRel(fx, fy)
    }

    private fun throwBall() {
        val c = applicationContext
        val r = screen()
        val p = Path().apply {
            moveTo(Config.get(c, "throwFromX") * r.width(), Config.get(c, "throwFromY") * r.height())
            lineTo(Config.get(c, "throwToX") * r.width(), Config.get(c, "throwToY") * r.height())
        }
        gesture(p, Config.get(c, "throwMs").toLong().coerceAtLeast(80L))
    }

    private fun shot(): Bitmap? {
        val gap = 1100L - (SystemClock.elapsedRealtime() - lastShotMs)
        if (gap > 0) sleepMs(gap)
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        lastShotMs = SystemClock.elapsedRealtime()
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                } catch (_: Throwable) {
                } finally {
                    result.hardwareBuffer.close()
                    latch.countDown()
                }
            }

            override fun onFailure(errorCode: Int) {
                latch.countDown()
            }
        })
        latch.await(5, TimeUnit.SECONDS)
        return out
    }

    private fun save(b: Bitmap) {
        try {
            val name = "shiny_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ShinyBot")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
        }
    }
}
