package com.lodtec.shinybot

import android.content.Context

data class Field(val key: String, val label: String, val def: Float, val group: String)

object Config {
    // Posicoes sao fracoes da tela (0 a 1): X = esquerda->direita, Y = topo->baixo.
    // Dica: use o botao CALIBRAR do bot em vez de digitar.
    val fields = listOf(
        Field("waitSec", "Espera após tocar no sniper (segundos)", 30f, "TEMPOS"),
        Field("openWaitMs", "Espera para abrir a captura (ms)", 2500f, "TEMPOS"),
        Field("postWaitSec", "Espera após jogar a pokébola (segundos)", 8f, "TEMPOS"),
        Field("cdMaxSec", "Espera máxima pelo timer verde (segundos)", 3600f, "TEMPOS"),

        Field("leftX", "Coluna esquerda, 1º Pokémon: X", 0.587f, "COLUNAS"),
        Field("leftY", "Coluna esquerda, 1º Pokémon: Y", 0.274f, "COLUNAS"),
        Field("rightX", "Coluna direita, 1º slot: X", 0.765f, "COLUNAS"),
        Field("rightY", "Coluna direita, 1º slot: Y", 0.274f, "COLUNAS"),
        Field("slotW", "Largura da área de detecção do slot", 0.09f, "COLUNAS"),
        Field("slotH", "Altura da área de detecção do slot", 0.045f, "COLUNAS"),

        Field("passOn", "Confirmar avisos sozinho: velocidade, clima... (1 = sim, 0 = não)", 1f, "AVISOS"),

        Field("diff", "Sensibilidade de cor (menor = mais sensível)", 60f, "DETECÇÃO"),
        Field("minPct", "% mínima de mudança no slot p/ achar Pokémon", 8f, "DETECÇÃO"),
        Field("colDiff", "Tolerância p/ achar a coluna esquerda (0 = não conferir)", 35f, "DETECÇÃO"),
        Field("capDiff", "Diferença mínima p/ confirmar tela de captura", 25f, "DETECÇÃO"),
        Field("timerL", "Timer no mapa: esquerda", 0.09f, "DETECÇÃO"),
        Field("timerT", "Timer no mapa: topo", 0.058f, "DETECÇÃO"),
        Field("timerR", "Timer no mapa: direita", 0.22f, "DETECÇÃO"),
        Field("timerB", "Timer no mapa: base", 0.074f, "DETECÇÃO"),
        Field("timer2L", "Timer na captura: esquerda", 0.105f, "DETECÇÃO"),
        Field("timer2T", "Timer na captura: topo", 0.106f, "DETECÇÃO"),
        Field("timer2R", "Timer na captura: direita", 0.23f, "DETECÇÃO"),
        Field("timer2B", "Timer na captura: base", 0.122f, "DETECÇÃO"),

        Field("throwFromX", "Arremesso, início: X", 0.5f, "ARREMESSO"),
        Field("throwFromY", "Arremesso, início: Y", 0.85f, "ARREMESSO"),
        Field("throwToX", "Arremesso, fim: X", 0.5f, "ARREMESSO"),
        Field("throwToY", "Arremesso, fim: Y", 0.35f, "ARREMESSO"),
        Field("throwMs", "Duração do arremesso (ms)", 250f, "ARREMESSO"),

        Field("savePrints", "Salvar print ao capturar (1 = sim, 0 = não)", 1f, "EXTRAS"),
        Field("startBubble", "Iniciar só com a bolinha, painel recolhido (1 = sim, 0 = não)", 1f, "EXTRAS"),
        Field("useBack", "Apertar VOLTAR após a captura (1 = sim, 0 = não)", 0f, "EXTRAS")
    )

    private fun sp(c: Context) = c.getSharedPreferences("shinybot_cfg", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float {
        val def = fields.first { it.key == key }.def
        return sp(c).getFloat(key, def)
    }

    fun set(c: Context, key: String, value: Float) {
        sp(c).edit().putFloat(key, value).apply()
    }

    fun reset(c: Context) {
        sp(c).edit().clear().apply()
    }
}
