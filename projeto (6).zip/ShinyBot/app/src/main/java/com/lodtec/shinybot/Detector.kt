package com.lodtec.shinybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

enum class TimerState { GREEN, RED, UNKNOWN }

object Detector {

    private fun px(b: Bitmap, x: Int, y: Int): Int =
        b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    private fun f(c: Context, k: String) = Config.get(c, k)

    /** % de pixels do 1o slot da coluna direita que MUDARAM entre dois prints. */
    fun slotChange(a: Bitmap, b: Bitmap, c: Context): Int {
        val w = minOf(a.width, b.width)
        val h = minOf(a.height, b.height)
        val x0 = ((f(c, "rightX") - f(c, "slotW") / 2f) * w).toInt()
        val x1 = ((f(c, "rightX") + f(c, "slotW") / 2f) * w).toInt()
        val y0 = ((f(c, "rightY") - f(c, "slotH") / 2f) * h).toInt()
        val y1 = ((f(c, "rightY") + f(c, "slotH") / 2f) * h).toInt()
        val limit = f(c, "diff").toInt()
        var total = 0
        var changed = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val pa = px(a, x, y)
                val pb = px(b, x, y)
                val d = abs(Color.red(pa) - Color.red(pb)) +
                    abs(Color.green(pa) - Color.green(pb)) +
                    abs(Color.blue(pa) - Color.blue(pb))
                if (d > limit) changed++
                total++
                x += 4
            }
            y += 4
        }
        return if (total == 0) 0 else changed * 100 / total
    }

    /** Diferenca media (0 a 255) entre dois prints inteiros. Mapa -> captura da um valor alto. */
    fun sceneDiff(a: Bitmap, b: Bitmap): Int {
        val w = minOf(a.width, b.width)
        val h = minOf(a.height, b.height)
        var sum = 0L
        var n = 0
        for (j in 0 until 48) {
            val y = (h * (0.20f + 0.60f * (j + 0.5f) / 48f)).toInt()
            for (i in 0 until 24) {
                val x = (w * (i + 0.5f) / 24f).toInt()
                val pa = px(a, x, y)
                val pb = px(b, x, y)
                sum += abs(Color.red(pa) - Color.red(pb)) +
                    abs(Color.green(pa) - Color.green(pb)) +
                    abs(Color.blue(pa) - Color.blue(pb))
                n++
            }
        }
        return (sum / (n * 3L)).toInt()
    }

    private fun countColors(b: Bitmap, l: Float, t: Float, r: Float, bt: Float): IntArray {
        val x0 = (l * b.width).toInt()
        val x1 = (r * b.width).toInt()
        val y0 = (t * b.height).toInt()
        val y1 = (bt * b.height).toInt()
        var green = 0
        var red = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val p = px(b, x, y)
                val pr = Color.red(p)
                val pg = Color.green(p)
                val pbl = Color.blue(p)
                if (pg > 150 && pg > pr + 60 && pg > pbl + 40) green++
                if (pr > 140 && pr > pg + 55 && pr > pbl + 55) red++
                x += 2
            }
            y += 2
        }
        return intArrayOf(green, red)
    }

    /** Timer do PGSharp: olha a posicao do mapa e a posicao da tela de captura. */
    fun timerState(b: Bitmap, c: Context): TimerState {
        val a1 = countColors(b, f(c, "timerL"), f(c, "timerT"), f(c, "timerR"), f(c, "timerB"))
        val a2 = countColors(b, f(c, "timer2L"), f(c, "timer2T"), f(c, "timer2R"), f(c, "timer2B"))
        val green = a1[0] + a2[0]
        val red = a1[1] + a2[1]
        val minPix = 8
        return when {
            red >= minPix && red > green -> TimerState.RED
            green >= minPix -> TimerState.GREEN
            else -> TimerState.UNKNOWN
        }
    }

    private fun lum(p: Int): Int =
        (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000

    /**
     * Confere se o ponto calibrado da coluna esquerda realmente esta sobre a lista do PGSharp:
     * ali existe um sprite (tem contraste) e o mesmo sprite se repete no slot logo abaixo.
     */
    fun leftColumnValid(b: Bitmap, c: Context): Boolean {
        val tol = f(c, "colDiff").toInt()
        if (tol <= 0) return true
        val w = b.width
        val h = b.height
        val cx = (f(c, "leftX") * w).toInt()
        val cy = (f(c, "leftY") * h).toInt()
        val hw = (0.035f * w).toInt()
        val hh = (0.016f * h).toInt()

        var sum = 0L
        var sum2 = 0L
        var n = 0
        var y = cy - hh
        while (y <= cy + hh) {
            var x = cx - hw
            while (x <= cx + hw) {
                val l = lum(px(b, x, y)).toLong()
                sum += l
                sum2 += l * l
                n++
                x += 3
            }
            y += 3
        }
        if (n == 0) return false
        val mean = sum.toDouble() / n
        val variance = sum2.toDouble() / n - mean * mean
        if (variance < 400.0) return false

        var best = Int.MAX_VALUE
        var dy = (0.040f * h).toInt()
        val dyMax = (0.072f * h).toInt()
        while (dy <= dyMax) {
            var d = 0L
            var m = 0
            y = cy - hh
            while (y <= cy + hh) {
                var x = cx - hw
                while (x <= cx + hw) {
                    val pa = px(b, x, y)
                    val pb = px(b, x, y + dy)
                    d += abs(Color.red(pa) - Color.red(pb)) +
                        abs(Color.green(pa) - Color.green(pb)) +
                        abs(Color.blue(pa) - Color.blue(pb))
                    m++
                    x += 3
                }
                y += 3
            }
            val avg = if (m == 0) Int.MAX_VALUE else (d / (m * 3L)).toInt()
            if (avg < best) best = avg
            dy += 2
        }
        return best <= tol
    }

    private fun isBtnGreen(p: Int): Boolean {
        val r = Color.red(p)
        val g = Color.green(p)
        val bl = Color.blue(p)
        return g > 150 && g > r + 15 && g > bl + 10
    }

    /**
     * Procura um botao verde largo em forma de pilula (estilo "SOU UM PASSAGEIRO" / "ESTOU SEGURO")
     * na parte de baixo do centro da tela. Retorna [x, y] como fracao da tela, ou null.
     */
    fun popupButton(b: Bitmap, c: Context): FloatArray? {
        if (f(c, "passOn") <= 0f) return null
        val w = b.width
        val h = b.height
        val step = maxOf(2, h / 400)
        val ys = ArrayList<Int>()
        val oks = ArrayList<Boolean>()
        var y = (0.45f * h).toInt()
        val yEnd = (0.85f * h).toInt()
        val xs = (0.25f * w).toInt()
        val xe = (0.75f * w).toInt()
        while (y <= yEnd) {
            var hit = 0
            var tot = 0
            var x = xs
            while (x <= xe) {
                if (isBtnGreen(px(b, x, y))) hit++
                tot++
                x += 6
            }
            ys.add(y)
            oks.add(tot > 0 && hit * 100 / tot >= 40)
            y += step
        }
        var i = 0
        while (i < ys.size) {
            if (!oks[i]) {
                i++
                continue
            }
            var last = i
            var k = i + 1
            while (k < ys.size && k - last <= 3) {
                if (oks[k]) last = k
                k++
            }
            val top = ys[i]
            val bottom = ys[last]
            val hh = (bottom - top).toFloat() / h
            if (hh >= 0.03f && hh <= 0.09f) {
                val my = (top + bottom) / 2
                val leftEdge = px(b, (0.08f * w).toInt(), my)
                val rightEdge = px(b, (0.92f * w).toInt(), my)
                if (!isBtnGreen(leftEdge) && !isBtnGreen(rightEdge)) {
                    return floatArrayOf(0.5f, my.toFloat() / h)
                }
            }
            i = last + 1
        }
        return null
    }
}
