package com.lodtec.shinybot

import android.content.Context

data class Field(val key: String, val label: String, val def: Float, val group: String)

object Config {
    // Todas as posicoes sao fracoes da tela (0 a 1): X = esquerda->direita, Y = topo->baixo.
    val fields = listOf(
        Field("waitSec", "Espera após tocar no sniper (segundos)", 30f, "TEMPOS"),
        Field("openWaitMs", "Espera para abrir a captura (ms)", 2500f, "TEMPOS"),
        Field("postWaitSec", "Espera após jogar a pokébola (segundos)", 8f, "TEMPOS"),

        Field("leftX", "Coluna esquerda, 1º Pokémon: X", 0.612f, "COLUNAS"),
        Field("leftY", "Coluna esquerda, 1º Pokémon: Y", 0.210f, "COLUNAS"),
        Field("rightX", "Coluna direita, 1º slot: X", 0.825f, "COLUNAS"),
        Field("rightY", "Coluna direita, 1º slot: Y", 0.210f, "COLUNAS"),
        Field("slotW", "Largura da área de detecção do slot", 0.08f, "COLUNAS"),
        Field("slotH", "Altura da área de detecção do slot", 0.04f, "COLUNAS"),
        Field("refX", "Ponto de fundo vazio da coluna direita: X", 0.825f, "COLUNAS"),
        Field("refY", "Ponto de fundo vazio da coluna direita: Y", 0.42f, "COLUNAS"),

        Field("diff", "Sensibilidade de cor (menor = mais sensível)", 60f, "DETECÇÃO"),
        Field("minPct", "% mínima de pixels diferentes p/ achar Pokémon", 6f, "DETECÇÃO"),
        Field("timerL", "Timer verde/vermelho: esquerda", 0.09f, "DETECÇÃO"),
        Field("timerT", "Timer verde/vermelho: topo", 0.058f, "DETECÇÃO"),
        Field("timerR", "Timer verde/vermelho: direita", 0.22f, "DETECÇÃO"),
        Field("timerB", "Timer verde/vermelho: base", 0.074f, "DETECÇÃO"),

        Field("throwFromX", "Arremesso, início: X", 0.5f, "ARREMESSO"),
        Field("throwFromY", "Arremesso, início: Y", 0.85f, "ARREMESSO"),
        Field("throwToX", "Arremesso, fim: X", 0.5f, "ARREMESSO"),
        Field("throwToY", "Arremesso, fim: Y", 0.35f, "ARREMESSO"),
        Field("throwMs", "Duração do arremesso (ms)", 250f, "ARREMESSO"),

        Field("savePrints", "Salvar print ao capturar (1 = sim, 0 = não)", 1f, "EXTRAS"),
        Field("useBack", "Apertar VOLTAR após a captura (1 = sim, 0 = não)", 0f, "EXTRAS")
    )

    private fun sp(c: Context) = c.getSharedPreferences("shinybot_cfg", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float {
        val def = fields.first { it.key == key }.def
        return sp(c).getFloat(key, def)
    }

    fun set(c: Context, key: String, value: Float) {
        sp(c).edit().putFloat(key, value).apply()
    }

    fun reset(c: Context) {
        sp(c).edit().clear().apply()
    }
}
