package com.lodtec.shinybot

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val edits = LinkedHashMap<String, EditText>()
    private lateinit var tvSvc: TextView

    private val BG = Color.parseColor("#0B0D1F")
    private val CARD = Color.parseColor("#141A40")
    private val NEON = Color.parseColor("#3DDC84")
    private val PURPLE = Color.parseColor("#7B5CD6")
    private val RED = Color.parseColor("#FF5C5C")
    private val TXT = Color.parseColor("#F2F4FF")
    private val MUTED = Color.parseColor("#8D96D6")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(12).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun fmt(v: Float): String = if (v % 1f == 0f) v.toInt().toString() else v.toString()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(fg)
            background = rounded(bg)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(40))
        }
        scroll.addView(root)

        root.addView(label("SHINY BOT", 30f, NEON, true))
        root.addView(label("Farm automático de shiny para PGSharp", 13f, MUTED))

        tvSvc = label("", 14f, TXT, true).apply {
            background = rounded(CARD, NEON)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(18) }
        }
        root.addView(tvSvc)

        root.addView(button("ATIVAR SERVIÇO DE ACESSIBILIDADE", NEON, BG) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val help = label(
            "1. Em Acessibilidade, ative o serviço \"Shiny Bot\".\n" +
                "2. Abra o Pokémon GO com o PGSharp.\n" +
                "3. A bolinha verde/vermelha flutua sobre o jogo: arraste para onde quiser e toque nela para abrir o menu (ON/OFF, PAINEL, TESTE, CALIBRAR, ZERAR). Segurar a bolinha parada liga/desliga o bot. TESTE mostra o que o bot está vendo (deixe a tela parada por 3s).\n" +
                "4. Calibre sempre que mudar as colunas do PGSharp de lugar.\n" +
                "5. Prints ficam em Pictures/ShinyBot.\n" +
                "Posições são frações da tela (0 a 1). Ajuste abaixo se precisar.",
            12f, MUTED
        ).apply {
            background = rounded(CARD)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        root.addView(help)

        var lastGroup = ""
        for (f in Config.fields) {
            if (f.group != lastGroup) {
                lastGroup = f.group
                root.addView(label(f.group, 12f, PURPLE, true).apply {
                    setPadding(0, dp(20), 0, dp(4))
                })
            }
            root.addView(label(f.label, 12f, TXT).apply { setPadding(0, dp(8), 0, 0) })
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(TXT)
                textSize = 15f
                background = rounded(CARD)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setText(fmt(Config.get(this@MainActivity, f.key)))
            }
            edits[f.key] = e
            root.addView(e)
        }

        root.addView(button("SALVAR AJUSTES", NEON, BG) { saveAll() })
        root.addView(button("RESTAURAR PADRÃO", CARD, TXT) {
            Config.reset(this)
            for (f in Config.fields) edits[f.key]?.setText(fmt(f.def))
            Toast.makeText(this, "Padrões restaurados", Toast.LENGTH_SHORT).show()
        })

        setContentView(scroll)
    }

    private fun saveAll() {
        val parsed = LinkedHashMap<String, Float>()
        for (f in Config.fields) {
            val v = edits[f.key]?.text?.toString()?.replace(',', '.')?.toFloatOrNull()
            if (v == null) {
                Toast.makeText(this, "Valor inválido: ${f.label}", Toast.LENGTH_LONG).show()
                return
            }
            parsed[f.key] = v
        }
        for ((k, v) in parsed) Config.set(this, k, v)
        Toast.makeText(this, "Ajustes salvos", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (BotService.instance != null) {
            tvSvc.text = "SERVIÇO ATIVO"
            tvSvc.setTextColor(NEON)
        } else {
            tvSvc.text = "SERVIÇO DESLIGADO"
            tvSvc.setTextColor(RED)
        }
    }
}
