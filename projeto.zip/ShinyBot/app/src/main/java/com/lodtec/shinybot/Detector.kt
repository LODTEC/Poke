package com.lodtec.shinybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

enum class TimerState { GREEN, RED, UNKNOWN }

object Detector {

    private fun px(b: Bitmap, x: Int, y: Int): Int =
        b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    private fun f(c: Context, k: String) = Config.get(c, k)

    /** % de pixels do 1o slot da coluna direita que MUDARAM entre dois prints. */
    fun slotChange(a: Bitmap, b: Bitmap, c: Context): Int {
        val w = minOf(a.width, b.width)
        val h = minOf(a.height, b.height)
        val x0 = ((f(c, "rightX") - f(c, "slotW") / 2f) * w).toInt()
        val x1 = ((f(c, "rightX") + f(c, "slotW") / 2f) * w).toInt()
        val y0 = ((f(c, "rightY") - f(c, "slotH") / 2f) * h).toInt()
        val y1 = ((f(c, "rightY") + f(c, "slotH") / 2f) * h).toInt()
        val limit = f(c, "diff").toInt()
        var total = 0
        var changed = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val pa = px(a, x, y)
                val pb = px(b, x, y)
                val d = abs(Color.red(pa) - Color.red(pb)) +
                    abs(Color.green(pa) - Color.green(pb)) +
                    abs(Color.blue(pa) - Color.blue(pb))
                if (d > limit) changed++
                total++
                x += 4
            }
            y += 4
        }
        return if (total == 0) 0 else changed * 100 / total
    }

    /** Diferenca media (0 a 255) entre dois prints inteiros. Mapa -> captura da um valor alto. */
    fun sceneDiff(a: Bitmap, b: Bitmap): Int {
        val w = minOf(a.width, b.width)
        val h = minOf(a.height, b.height)
        var sum = 0L
        var n = 0
        for (j in 0 until 48) {
            val y = (h * (0.20f + 0.60f * (j + 0.5f) / 48f)).toInt()
            for (i in 0 until 24) {
                val x = (w * (i + 0.5f) / 24f).toInt()
                val pa = px(a, x, y)
                val pb = px(b, x, y)
                sum += abs(Color.red(pa) - Color.red(pb)) +
                    abs(Color.green(pa) - Color.green(pb)) +
                    abs(Color.blue(pa) - Color.blue(pb))
                n++
            }
        }
        return (sum / (n * 3L)).toInt()
    }

    private fun countColors(b: Bitmap, l: Float, t: Float, r: Float, bt: Float): IntArray {
        val x0 = (l * b.width).toInt()
        val x1 = (r * b.width).toInt()
        val y0 = (t * b.height).toInt()
        val y1 = (bt * b.height).toInt()
        var green = 0
        var red = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val p = px(b, x, y)
                val pr = Color.red(p)
                val pg = Color.green(p)
                val pbl = Color.blue(p)
                if (pg > 150 && pg > pr + 60 && pg > pbl + 40) green++
                if (pr > 140 && pr > pg + 55 && pr > pbl + 55) red++
                x += 2
            }
            y += 2
        }
        return intArrayOf(green, red)
    }

    /** Timer do PGSharp: olha a posicao do mapa e a posicao da tela de captura. */
    fun timerState(b: Bitmap, c: Context): TimerState {
        val a1 = countColors(b, f(c, "timerL"), f(c, "timerT"), f(c, "timerR"), f(c, "timerB"))
        val a2 = countColors(b, f(c, "timer2L"), f(c, "timer2T"), f(c, "timer2R"), f(c, "timer2B"))
        val green = a1[0] + a2[0]
        val red = a1[1] + a2[1]
        val minPix = 8
        return when {
            red >= minPix && red > green -> TimerState.RED
            green >= minPix -> TimerState.GREEN
            else -> TimerState.UNKNOWN
        }
    }

    private fun whiteFrac(b: Bitmap, x0f: Float, x1f: Float, y0f: Float, y1f: Float): Float {
        val x0 = (x0f * b.width).toInt()
        val x1 = (x1f * b.width).toInt()
        val y0 = (y0f * b.height).toInt()
        val y1 = (y1f * b.height).toInt()
        var total = 0
        var white = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val p = px(b, x, y)
                if (minOf(Color.red(p), Color.green(p), Color.blue(p)) >= 225) white++
                total++
                x += 6
            }
            y += 3
        }
        return if (total == 0) 0f else white.toFloat() / total
    }

    /** Detecta o cartao branco "Esta andando muito rapido" com o botao verde SOU UM PASSAGEIRO. */
    fun passengerCard(b: Bitmap, c: Context): Boolean {
        if (f(c, "passOn") <= 0f) return false
        val top = whiteFrac(b, 0.10f, 0.90f, 0.295f, 0.315f)
        val bottom = whiteFrac(b, 0.10f, 0.90f, 0.700f, 0.712f)
        if (top < 0.5f || bottom < 0.5f) return false
        val cx = (f(c, "passX") * b.width).toInt()
        val cy = (f(c, "passY") * b.height).toInt()
        var r = 0
        var g = 0
        var n = 0
        for (dy in -8..8 step 4) {
            for (dx in -8..8 step 4) {
                val p = px(b, cx + dx, cy + dy)
                r += Color.red(p)
                g += Color.green(p)
                n++
            }
        }
        r /= n
        g /= n
        return g > 150 && g > r + 15
    }
}
