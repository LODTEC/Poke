package com.lodtec.shinybot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

enum class TimerState { GREEN, RED, UNKNOWN }

data class Analysis(
    val pokemon: Boolean,
    val pct: Int,
    val timer: TimerState,
    val green: Int,
    val red: Int
)

object Detector {

    private fun px(b: Bitmap, x: Int, y: Int): Int =
        b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    private fun avgColor(b: Bitmap, cx: Int, cy: Int): IntArray {
        var r = 0; var g = 0; var bl = 0; var n = 0
        for (dy in -4..4 step 2) {
            for (dx in -4..4 step 2) {
                val p = px(b, cx + dx, cy + dy)
                r += Color.red(p); g += Color.green(p); bl += Color.blue(p); n++
            }
        }
        return intArrayOf(r / n, g / n, bl / n)
    }

    fun analyze(b: Bitmap, c: Context): Analysis {
        val w = b.width
        val h = b.height
        fun f(k: String) = Config.get(c, k)

        // 1) Existe algo no 1o slot da coluna direita?
        val ref = avgColor(b, (f("refX") * w).toInt(), (f("refY") * h).toInt())
        val x0 = ((f("rightX") - f("slotW") / 2f) * w).toInt()
        val x1 = ((f("rightX") + f("slotW") / 2f) * w).toInt()
        val y0 = ((f("rightY") - f("slotH") / 2f) * h).toInt()
        val y1 = ((f("rightY") + f("slotH") / 2f) * h).toInt()
        val limit = f("diff").toInt()
        var total = 0
        var different = 0
        var y = y0
        while (y <= y1) {
            var x = x0
            while (x <= x1) {
                val p = px(b, x, y)
                val d = abs(Color.red(p) - ref[0]) + abs(Color.green(p) - ref[1]) + abs(Color.blue(p) - ref[2])
                if (d > limit) different++
                total++
                x += 4
            }
            y += 4
        }
        val pct = if (total == 0) 0 else different * 100 / total
        val pokemon = pct >= f("minPct").toInt()

        // 2) Timer do topo: verde (pronto) ou vermelho (cooldown)?
        val tx0 = (f("timerL") * w).toInt()
        val tx1 = (f("timerR") * w).toInt()
        val ty0 = (f("timerT") * h).toInt()
        val ty1 = (f("timerB") * h).toInt()
        var green = 0
        var red = 0
        y = ty0
        while (y <= ty1) {
            var x = tx0
            while (x <= tx1) {
                val p = px(b, x, y)
                val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
                if (g > 150 && g > r + 60 && g > bl + 40) green++
                if (r > 150 && r > g + 80 && r > bl + 80) red++
                x += 2
            }
            y += 2
        }
        val minPix = 8
        val timer = when {
            red >= minPix && red > green -> TimerState.RED
            green >= minPix -> TimerState.GREEN
            else -> TimerState.UNKNOWN
        }
        return Analysis(pokemon, pct, timer, green, red)
    }
}
